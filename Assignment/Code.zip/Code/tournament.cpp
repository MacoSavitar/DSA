#ifndef _definition_h_
#include "defs.h"
#define _definition_h_
#endif

ringsignList *combat(knight &theKnight, eventList *pEvent)
{
	ringsignList *pList = NULL;
	//fighting for honor and love here
	pList->nRingsign = theKnight.nInitRingsign;
	pList->pNext = NULL;
	int numEvent = 0;
	int maxHP = theKnight.HP;
	bool theKnightDead = false;
	while (pEvent)
	{
		numEvent += 1;
		//S1
		if (pEvent->nEventCode == 0)
		{
			break;
		}
		//S2
		if ((pEvent->nEventCode >= 10 && pEvent->nEventCode <= 69) || (pEvent->nEventCode >= 90 && pEvent->nEventCode <= 99))
		{
			int b = numEvent % 10;
			int levelO = numEvent > 6 ? (b > 5 ? b : 5) : b;

			int baseDamage = 0;
			//Uruk-hai
			if (pEvent->nEventCode >= 10 && pEvent->nEventCode <= 19)
				baseDamage = 10;
			//Ringrwaiths
			if (pEvent->nEventCode >= 20 && pEvent->nEventCode <= 29)
				baseDamage = 18;
			//Strider
			if (pEvent->nEventCode >= 30 && pEvent->nEventCode <= 39)
				baseDamage = 45;
			//Gollum
			if (pEvent->nEventCode >= 40 && pEvent->nEventCode <= 49)
				baseDamage = 82;
			//Luitz
			if (pEvent->nEventCode >= 50 && pEvent->nEventCode <= 59)
				baseDamage = 75;
			//Gimli
			if (pEvent->nEventCode >= 60 && pEvent->nEventCode <= 69)
				baseDamage = 90;
			//Saruman
			if (pEvent->nEventCode >= 90 && pEvent->nEventCode <= 99)
				baseDamage = 1;
			//Win
			if (theKnight.level > levelO)
			{
				ringsignList *q = pList;
				while (q)
					q = q->pNext;
				q->nRingsign = pEvent->nEventCode % 10;
				q->pNext = NULL;
			}
			//Lose
			if (theKnight.level < levelO)
			{
				theKnight.HP -= baseDamage * levelO;
				if (theKnight.HP <= 0)
					theKnightDead = true;
			}
			//S3
			if (pEvent->nEventCode == 7)
			{
				int ECCode = 0;
				ringsignList *q = pList;
				while (q)
				{
					ECCode = ECCode * 10 + q->nRingsign;
					q = q->pNext;
				}
				ECCode += 1;
				ringsignList *newPList = NULL;
				while (ECCode >= 10)
				{
					ringsignList *pNew;
					pNew->nRingsign = ECCode % 10;
					if (newPList == NULL)
					{
						newPList = pNew;
					}
					else
					{
						p
					}
					ECCode /= 10;
				}
			}
			//S4
			if (pEvent->nEventCode == 8)
			{
			}
		}
	}

	return pList;
}

int checkPalindrome(ringsignList *pRingsign)
{
	return 0;
}
